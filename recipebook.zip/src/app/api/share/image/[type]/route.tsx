import { NextRequest } from "next/server";
import { publicConfig } from "@/config/public-config";
import {
  getShareImageResponse,
  parseNextRequestSearchParams,
} from "@/neynar-farcaster-sdk/nextjs";

// Cache for 1 hour - query strings create separate cache entries
export const revalidate = 3600;

const { appEnv, heroImageUrl, imageUrl } = publicConfig;

const showDevWarning = appEnv !== "production";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ type: string }> },
) {
  const { type } = await params;

  const searchParams = parseNextRequestSearchParams(request);
  const recipeTitle = searchParams.recipeTitle ?? "";
  const recipeEmoji = searchParams.recipeEmoji ?? "📖";

  return getShareImageResponse(
    { type, heroImageUrl, imageUrl, showDevWarning },
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-end",
        width: "100%",
        height: "100%",
        padding: 48,
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 16,
          backgroundColor: "rgba(15, 14, 13, 0.88)",
          borderRadius: 24,
          padding: "32px 40px",
          border: "1px solid rgba(212, 160, 23, 0.25)",
          boxShadow: "0 12px 48px rgba(0, 0, 0, 0.6)",
        }}
      >
        {/* App name row */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ display: "flex", fontSize: 28 }}>📖</div>
          <div
            style={{
              display: "flex",
              fontSize: 18,
              fontWeight: "bold",
              color: "#f5f0e8",
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Recipebook
          </div>
        </div>

        {/* Divider */}
        <div
          style={{
            display: "flex",
            height: 1,
            backgroundColor: "rgba(212, 160, 23, 0.3)",
          }}
        />

        {/* Recipe row */}
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 72,
              height: 72,
              borderRadius: 16,
              backgroundColor: "rgba(212, 160, 23, 0.12)",
              border: "1px solid rgba(212, 160, 23, 0.25)",
              fontSize: 40,
            }}
          >
            {recipeEmoji}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {recipeTitle ? (
              <div
                style={{
                  display: "flex",
                  fontSize: 40,
                  fontWeight: "bold",
                  color: "#f5f0e8",
                  maxWidth: 480,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {recipeTitle}
              </div>
            ) : null}
            <div
              style={{
                display: "flex",
                fontSize: 20,
                color: "#d4a017",
                fontStyle: "italic",
              }}
            >
              Cook something amazing
            </div>
          </div>
        </div>
      </div>
    </div>,
  );
}
