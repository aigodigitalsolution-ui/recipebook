"use server";

import { db } from "@/db";
import { recipeLikes } from "@/db/schema";
import { eq, sql, inArray } from "drizzle-orm";

/**
 * Get global like counts for a list of recipe IDs.
 * Returns a map of recipeId -> likeCount.
 */
export async function getLikeCounts(
  recipeIds: string[]
): Promise<Record<string, number>> {
  if (recipeIds.length === 0) return {};

  const rows = await db
    .select()
    .from(recipeLikes)
    .where(inArray(recipeLikes.recipeId, recipeIds));

  const map: Record<string, number> = {};
  for (const row of rows) {
    map[row.recipeId] = row.likeCount;
  }
  return map;
}

/**
 * Increment the global like count for a recipe.
 * Uses upsert so it works even if the row doesn't exist yet.
 */
export async function incrementLike(recipeId: string): Promise<number> {
  const [row] = await db
    .insert(recipeLikes)
    .values({ recipeId, likeCount: 1 })
    .onConflictDoUpdate({
      target: recipeLikes.recipeId,
      set: {
        likeCount: sql`${recipeLikes.likeCount} + 1`,
      },
    })
    .returning();

  return row.likeCount;
}

/**
 * Decrement the global like count for a recipe (min 0).
 */
export async function decrementLike(recipeId: string): Promise<number> {
  const existing = await db
    .select()
    .from(recipeLikes)
    .where(eq(recipeLikes.recipeId, recipeId))
    .limit(1);

  if (existing.length === 0) return 0;

  const newCount = Math.max(0, existing[0].likeCount - 1);
  await db
    .update(recipeLikes)
    .set({ likeCount: newCount })
    .where(eq(recipeLikes.recipeId, recipeId));

  return newCount;
}
