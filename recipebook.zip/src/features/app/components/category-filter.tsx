"use client";

import { cn } from "@neynar/ui";
import { CATEGORIES } from "@/features/app/data/recipes";
import type { RecipeCategory } from "@/features/app/types";

interface CategoryFilterProps {
  selected: RecipeCategory | "all";
  onChange: (category: RecipeCategory | "all") => void;
}

export function CategoryFilter({ selected, onChange }: CategoryFilterProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
      {CATEGORIES.map((cat) => (
        <button
          key={cat.id}
          onClick={() => onChange(cat.id as RecipeCategory | "all")}
          className={cn(
            "shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-all duration-200",
            "border min-h-[36px]",
            selected === cat.id
              ? "bg-[#d4a017] border-[#d4a017] text-[#0f0e0d]"
              : "bg-[#1a1814] border-[#2e2820] text-[#c4b99a] hover:border-[#d4a017]/40 hover:text-[#f5f0e8]"
          )}
        >
          <span>{cat.emoji}</span>
          <span>{cat.label}</span>
        </button>
      ))}
    </div>
  );
}
