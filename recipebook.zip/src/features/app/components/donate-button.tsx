"use client";

import { useState } from "react";
import { ExperimentalTransferUsdcButton } from "@/neynar-web-sdk/blockchain";
import { cn } from "@neynar/ui";

const RECIPIENT = "0x9Ac46fc94580D69133256eb9b724322010929Ffb";
const QUICK_AMOUNTS = [1, 2];

export function DonateButton() {
  const [selected, setSelected] = useState<number>(1);
  const [customInput, setCustomInput] = useState("");
  const [isCustom, setIsCustom] = useState(false);
  const [donated, setDonated] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const amount = isCustom ? (parseFloat(customInput) || 0) : selected;
  const isValid = amount > 0;

  function handleQuickSelect(amt: number) {
    setSelected(amt);
    setIsCustom(false);
    setCustomInput("");
    setErrorMsg("");
  }

  function handleCustomChange(val: string) {
    setCustomInput(val.replace(/[^0-9.]/g, ""));
    setIsCustom(true);
    setErrorMsg("");
  }

  function handleSuccess() {
    setDonated(true);
    setErrorMsg("");
    setTimeout(() => setDonated(false), 4000);
  }

  function handleError(error: Error) {
    if (
      error.name === "UserRejectedRequestError" ||
      error.message?.includes("user rejected")
    ) return;
    setErrorMsg("Transaction failed. Please try again.");
    setTimeout(() => setErrorMsg(""), 3000);
  }

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center gap-2">
        {/* Quick amounts */}
        {QUICK_AMOUNTS.map((amt) => (
          <button
            key={amt}
            onClick={() => handleQuickSelect(amt)}
            className={cn(
              "h-9 px-3 rounded-lg text-xs font-semibold border transition-all duration-150 shrink-0",
              !isCustom && selected === amt
                ? "bg-[#d4a017] border-[#d4a017] text-[#0f0e0d]"
                : "bg-[#0f0e0d] border-[#2e2820] text-[#c4b99a] hover:border-[#d4a017]/40"
            )}
          >
            ${amt}
          </button>
        ))}

        {/* Custom input */}
        <div className={cn(
          "relative h-9 flex items-center rounded-lg border transition-all duration-150 shrink-0",
          isCustom ? "border-[#d4a017]/60 bg-[#0f0e0d]" : "border-[#2e2820] bg-[#0f0e0d]"
        )}>
          <span className="pl-2 text-xs text-[#8a7a62]">$</span>
          <input
            type="number"
            min="0"
            step="1"
            placeholder="other"
            value={customInput}
            onChange={(e) => handleCustomChange(e.target.value)}
            onFocus={() => setIsCustom(true)}
            className="w-14 h-full bg-transparent text-xs text-[#f5f0e8] placeholder:text-[#8a7a62] focus:outline-none px-1"
          />
        </div>

        {/* Send button */}
        <ExperimentalTransferUsdcButton
          to={RECIPIENT}
          amountUsdc={amount}
          disabled={!isValid}
          onSuccess={handleSuccess}
          onError={handleError}
          className="h-9 flex-1 rounded-lg text-xs font-semibold transition-all duration-200"
        >
          {donated ? "Thanks ❤️" : `Tip $${amount > 0 ? amount : "?"}`}
        </ExperimentalTransferUsdcButton>
      </div>

      {/* Inline error */}
      {errorMsg && (
        <p className="text-[10px] text-rose-400 px-1">{errorMsg}</p>
      )}

      {/* Success message */}
      {donated && (
        <p className="text-[10px] text-emerald-400 px-1">Thank you for your support! ❤️</p>
      )}
    </div>
  );
}
