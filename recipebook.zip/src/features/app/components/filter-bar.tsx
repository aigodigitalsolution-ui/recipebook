"use client";

import { cn } from "@neynar/ui";
import { CATEGORIES, CUISINES, SPICE_FILTERS, DIETARY_FILTERS } from "@/features/app/data/recipes";
import type { RecipeCategory, Cuisine, DietaryTag } from "@/features/app/types";

interface FilterBarProps {
  activeCategory: RecipeCategory | "all";
  activeCuisine: Cuisine | "all";
  activeSpice: "all" | "mild" | "spicy";
  activeDietary: DietaryTag | "all";
  onCategoryChange: (v: RecipeCategory | "all") => void;
  onCuisineChange: (v: Cuisine | "all") => void;
  onSpiceChange: (v: "all" | "mild" | "spicy") => void;
  onDietaryChange: (v: DietaryTag | "all") => void;
}

function FilterRow<T extends string>({
  items,
  selected,
  onChange,
}: {
  items: readonly { id: string; label: string; emoji: string }[];
  selected: T;
  onChange: (id: T) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => onChange(item.id as T)}
          className={cn(
            "shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 border min-h-[32px]",
            selected === item.id
              ? "bg-[#d4a017] border-[#d4a017] text-[#0f0e0d]"
              : "bg-[#1a1814] border-[#2e2820] text-[#c4b99a] hover:border-[#d4a017]/40 hover:text-[#f5f0e8]"
          )}
        >
          <span>{item.emoji}</span>
          <span>{item.label}</span>
        </button>
      ))}
    </div>
  );
}

export function FilterBar({
  activeCategory,
  activeCuisine,
  activeSpice,
  activeDietary,
  onCategoryChange,
  onCuisineChange,
  onSpiceChange,
  onDietaryChange,
}: FilterBarProps) {
  return (
    <div className="flex flex-col gap-2 py-2">
      <div className="flex items-center gap-2 px-4">
        <span className="text-[10px] font-semibold uppercase tracking-widest text-[#8a7a62] shrink-0 w-12">Meal</span>
        <FilterRow items={CATEGORIES} selected={activeCategory} onChange={onCategoryChange} />
      </div>
      <div className="flex items-center gap-2 px-4">
        <span className="text-[10px] font-semibold uppercase tracking-widest text-[#8a7a62] shrink-0 w-12">Origin</span>
        <FilterRow items={CUISINES} selected={activeCuisine} onChange={onCuisineChange} />
      </div>
      <div className="flex items-center gap-2 px-4">
        <span className="text-[10px] font-semibold uppercase tracking-widest text-[#8a7a62] shrink-0 w-12">Diet</span>
        <FilterRow items={DIETARY_FILTERS} selected={activeDietary} onChange={onDietaryChange} />
      </div>
      <div className="flex items-center gap-2 px-4">
        <span className="text-[10px] font-semibold uppercase tracking-widest text-[#8a7a62] shrink-0 w-12">Heat</span>
        <FilterRow items={SPICE_FILTERS} selected={activeSpice} onChange={onSpiceChange} />
      </div>
    </div>
  );
}
