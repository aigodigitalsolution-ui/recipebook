"use client";

import { useState } from "react";
import { cn } from "@neynar/ui";

interface LikeButtonProps {
  recipeId: string;
  liked: boolean;
  onToggle: (id: string) => void;
  size?: "sm" | "md";
}

export function LikeButton({ recipeId, liked, onToggle, size = "md" }: LikeButtonProps) {
  const [burst, setBurst] = useState(false);

  function handleClick(e: React.MouseEvent) {
    e.stopPropagation();
    onToggle(recipeId);
    if (!liked) {
      setBurst(true);
      setTimeout(() => setBurst(false), 400);
    }
  }

  const isSmall = size === "sm";

  return (
    <button
      onClick={handleClick}
      aria-label={liked ? "Unlike recipe" : "Like recipe"}
      className={cn(
        "relative flex items-center justify-center rounded-full border transition-all duration-200 shrink-0",
        "active:scale-90",
        isSmall
          ? "w-8 h-8"
          : "w-10 h-10",
        liked
          ? "bg-rose-500/15 border-rose-500/40 text-rose-400"
          : "bg-[#1a1814] border-[#2e2820] text-[#8a7a62] hover:border-rose-500/30 hover:text-rose-400/70"
      )}
    >
      <span
        className={cn(
          "transition-transform duration-200",
          isSmall ? "text-base" : "text-xl",
          burst && "scale-125"
        )}
      >
        {liked ? "❤️" : "🤍"}
      </span>

      {/* Burst ring animation */}
      {burst && (
        <span className="absolute inset-0 rounded-full border-2 border-rose-400 animate-ping opacity-60" />
      )}
    </button>
  );
}
