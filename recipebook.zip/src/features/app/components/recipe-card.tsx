"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, cn } from "@neynar/ui";
import Image from "next/image";
import type { Recipe } from "@/features/app/types";
import { CUISINES } from "@/features/app/data/recipes";
import { LikeButton } from "@/features/app/components/like-button";

interface RecipeCardProps {
  recipe: Recipe;
  liked: boolean;
  onLike: (id: string) => void;
  onClick: (recipe: Recipe) => void;
  globalLikeCount?: number;
  showDate?: boolean;
}

const DIFFICULTY_COLORS: Record<string, string> = {
  easy: "text-emerald-400 bg-emerald-400/10",
  medium: "text-amber-400 bg-amber-400/10",
  hard: "text-rose-400 bg-rose-400/10",
};

const SPICE_LABEL: Record<string, string> = {
  medium: "🌶️",
  hot: "🌶️🌶️",
};

export function RecipeCard({ recipe, liked, onLike, onClick, globalLikeCount = 0, showDate = false }: RecipeCardProps) {
  const totalTime = recipe.prepTime + recipe.cookTime;
  const cuisineInfo = CUISINES.find((c) => c.id === recipe.cuisine);

  // Client-only: compute date label after hydration to avoid SSR mismatch
  const [dateLabel, setDateLabel] = useState<string>("");
  useEffect(() => {
    if (!showDate) return;
    const date = new Date(recipe.addedAt);
    const diffDays = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays === 0) setDateLabel("Added today");
    else if (diffDays === 1) setDateLabel("Added yesterday");
    else setDateLabel(`Added ${diffDays} days ago`);
  }, [showDate, recipe.addedAt]);

  return (
    <Card
      className={cn(
        "cursor-pointer border-[#2e2820] bg-[#1a1814] transition-all duration-200 overflow-hidden",
        "hover:border-[#d4a017]/40 active:scale-[0.98] active:bg-[#201d18]",
        liked && "border-rose-500/20"
      )}
      onClick={() => onClick(recipe)}
    >
      <CardContent className="p-0">
        <div className="flex items-stretch gap-0">
          {/* Food photo */}
          <div className="relative w-24 h-24 shrink-0">
            <Image
              src={recipe.imageUrl}
              alt={recipe.title}
              fill
              className="object-cover"
              sizes="96px"
              loading="eager"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#1a1814]/40" />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 px-3 py-3">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-semibold text-[#f5f0e8] text-sm leading-tight line-clamp-1">
                {recipe.title}
              </h3>
              <div className="flex items-center gap-1 shrink-0">
                <span
                  className={cn(
                    "text-[10px] font-medium px-1.5 py-0.5 rounded-full capitalize",
                    DIFFICULTY_COLORS[recipe.difficulty]
                  )}
                >
                  {recipe.difficulty}
                </span>
                <LikeButton
                  recipeId={recipe.id}
                  liked={liked}
                  onToggle={onLike}
                  size="sm"
                />
              </div>
            </div>

            <p className="text-[#c4b99a] text-xs mt-1 line-clamp-2 leading-relaxed">
              {recipe.description}
            </p>

            {/* Meta row */}
            <div className="flex items-center gap-2.5 mt-2 flex-wrap">
              <span className="text-[10px] text-[#8a7a62] flex items-center gap-0.5">
                <span>⏱</span>
                <span>{totalTime}m</span>
              </span>
              {cuisineInfo && (
                <span className="text-[10px] text-[#8a7a62] flex items-center gap-0.5">
                  <span>{cuisineInfo.emoji}</span>
                  <span>{cuisineInfo.label}</span>
                </span>
              )}
              {recipe.spicy && recipe.spiceLevel && (
                <span className="text-[10px] text-rose-400 bg-rose-400/10 px-1.5 py-0.5 rounded-full">
                  {SPICE_LABEL[recipe.spiceLevel] ?? "🌶️"} Spicy
                </span>
              )}
              <span className="text-[10px] text-[#8a7a62] flex items-center gap-0.5">
                <span>🔥</span>
                <span>{recipe.calories} kcal</span>
              </span>
              {recipe.dietary.slice(0, 2).map((d) => (
                <span key={d} className="text-[10px] text-emerald-400/80 bg-emerald-400/10 px-1.5 py-0.5 rounded-full capitalize">
                  {d === "gluten-free" ? "GF" : d === "dairy-free" ? "DF" : d === "high-protein" ? "💪" : d === "vegan" ? "🌱" : "🥦"}
                </span>
              ))}
              {showDate && dateLabel && (
                <span className="text-[10px] text-[#d4a017]/80 flex items-center gap-0.5">
                  <span>🗓</span>
                  <span>{dateLabel}</span>
                </span>
              )}
              {globalLikeCount > 0 && (
                <span className="text-[10px] text-rose-400/70 flex items-center gap-0.5 ml-auto">
                  <span>❤️</span>
                  <span>{globalLikeCount.toLocaleString()}</span>
                </span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
