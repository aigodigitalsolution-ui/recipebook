"use client";

import Image from "next/image";
import type { Recipe } from "@/features/app/types";
import { LikeButton } from "@/features/app/components/like-button";
import { DonateButton } from "@/features/app/components/donate-button";
import { CUISINES } from "@/features/app/data/recipes";

interface RecipeDetailProps {
  recipe: Recipe;
  liked: boolean;
  onLike: (id: string) => void;
  onBack: () => void;
  shareButton?: React.ReactNode;
  shareIconButton?: React.ReactNode;
  globalLikeCount?: number;
}

const DIFFICULTY_COLORS: Record<string, string> = {
  easy: "text-emerald-400 bg-emerald-400/10 border-emerald-400/20",
  medium: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  hard: "text-rose-400 bg-rose-400/10 border-rose-400/20",
};

export function RecipeDetail({ recipe, liked, onLike, onBack, shareButton, shareIconButton, globalLikeCount = 0 }: RecipeDetailProps) {
  const totalTime = recipe.prepTime + recipe.cookTime;
  const cuisineInfo = CUISINES.find((c) => c.id === recipe.cuisine);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <header className="shrink-0 flex items-center gap-3 px-4 py-3 border-b border-[#2e2820]">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-full bg-[#1a1814] border border-[#2e2820] flex items-center justify-center text-[#c4b99a] hover:text-[#f5f0e8] hover:border-[#d4a017]/40 transition-colors"
        >
          ←
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="font-semibold text-[#f5f0e8] text-base truncate">
            {recipe.title}
          </h2>
          {globalLikeCount > 0 && (
            <p className="text-[10px] text-rose-400/70 mt-0.5">
              ❤️ {globalLikeCount.toLocaleString()} {globalLikeCount === 1 ? "person loves" : "people love"} this
            </p>
          )}
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {shareIconButton}
          <LikeButton
            recipeId={recipe.id}
            liked={liked}
            onToggle={onLike}
            size="md"
          />
        </div>
      </header>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        {/* Hero photo */}
        <div className="relative w-full h-48 shrink-0">
          <Image
            src={recipe.imageUrl}
            alt={recipe.title}
            fill
            className="object-cover"
            sizes="424px"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0f0e0d] via-[#0f0e0d]/20 to-transparent" />
          {/* Title overlay */}
          <div className="absolute bottom-0 left-0 right-0 px-4 pb-3">
            <h1 className="text-xl font-bold text-white leading-tight drop-shadow-lg">
              {recipe.title}
            </h1>
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <span
                className={`inline-block text-xs font-medium px-2.5 py-0.5 rounded-full border capitalize ${DIFFICULTY_COLORS[recipe.difficulty]}`}
              >
                {recipe.difficulty}
              </span>
              {cuisineInfo && (
                <span className="inline-flex items-center gap-1 text-xs text-white/80 bg-black/30 backdrop-blur-sm px-2.5 py-0.5 rounded-full">
                  <span>{cuisineInfo.emoji}</span>
                  <span>{cuisineInfo.label}</span>
                </span>
              )}
              {recipe.spicy && (
                <span className="inline-block text-xs text-rose-300 bg-rose-500/20 backdrop-blur-sm border border-rose-400/20 px-2.5 py-0.5 rounded-full">
                  🌶️ Spicy
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Description + stats */}
        <div className="px-4 pt-4 pb-4">
          <p className="text-sm text-[#c4b99a] leading-relaxed">
            {recipe.description}
          </p>

          {/* Stats row */}
          <div className="grid grid-cols-5 gap-2 mt-4">
            {[
              { label: "Prep", value: `${recipe.prepTime}m` },
              { label: "Cook", value: recipe.cookTime > 0 ? `${recipe.cookTime}m` : "None" },
              { label: "Total", value: `${totalTime}m` },
              { label: "Serves", value: recipe.servings.toString() },
              { label: "Calories", value: `${recipe.calories}` },
            ].map((stat) => (
              <div
                key={stat.label}
                className="bg-[#1a1814] border border-[#2e2820] rounded-xl p-2.5 text-center"
              >
                <div className="text-base font-bold text-[#d4a017]">
                  {stat.value}
                </div>
                <div className="text-xs text-[#8a7a62] mt-0.5">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Ingredients */}
        <section className="px-4 pt-2 pb-4">
          <h3 className="text-xs font-semibold text-[#d4a017] uppercase tracking-wider mb-3">
            Ingredients
          </h3>
          <div className="space-y-2">
            {recipe.ingredients.map((ing, i) => (
              <div
                key={i}
                className="flex items-center gap-3 py-2.5 px-3 rounded-xl bg-[#1a1814] border border-[#2e2820]"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-[#d4a017] shrink-0" />
                <span className="text-sm text-[#f5f0e8] flex-1">{ing.name}</span>
                <span className="text-sm text-[#c4b99a] text-right shrink-0">
                  {[ing.amount, ing.unit].filter(Boolean).join(" ")}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Steps */}
        <section className="px-4 pb-4">
          <h3 className="text-xs font-semibold text-[#d4a017] uppercase tracking-wider mb-3">
            Method
          </h3>
          <div className="space-y-3">
            {recipe.steps.map((step, i) => (
              <div key={i} className="flex gap-3">
                <div className="shrink-0 w-7 h-7 rounded-full bg-[#d4a017]/10 border border-[#d4a017]/20 flex items-center justify-center">
                  <span className="text-xs font-bold text-[#d4a017]">
                    {i + 1}
                  </span>
                </div>
                <p className="text-sm text-[#c4b99a] leading-relaxed pt-0.5 flex-1">
                  {step}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Dietary + Tags */}
        <section className="px-4 pb-6">
          {recipe.dietary.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {recipe.dietary.map((d) => {
                const DIETARY_ICONS: Record<string, string> = {
                  vegan: "🌱 Vegan",
                  vegetarian: "🥦 Vegetarian",
                  "gluten-free": "🌾 Gluten-Free",
                  "dairy-free": "🥛 Dairy-Free",
                  "high-protein": "💪 High Protein",
                };
                return (
                  <span key={d} className="text-xs text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-3 py-1 rounded-full">
                    {DIETARY_ICONS[d] ?? d}
                  </span>
                );
              })}
            </div>
          )}
          {recipe.tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {recipe.tags.map((tag) => (
                <span key={tag} className="text-xs text-[#8a7a62] bg-[#1a1814] border border-[#2e2820] px-3 py-1 rounded-full">
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Footer */}
      <div className="shrink-0 px-4 pt-3 pb-4 border-t border-[#2e2820] bg-[#0f0e0d]">
        {/* Donate */}
        <div className="rounded-xl bg-[#1a1814] border border-[#2e2820] px-3 py-2.5">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm">💛</span>
            <span className="text-xs font-semibold text-[#f5f0e8]">Support the cookbook</span>
            <span className="ml-auto text-[10px] text-[#8a7a62] bg-[#0f0e0d] border border-[#2e2820] px-1.5 py-0.5 rounded-full">Base · USDC</span>
          </div>
          <DonateButton />
        </div>
      </div>
    </div>
  );
}
