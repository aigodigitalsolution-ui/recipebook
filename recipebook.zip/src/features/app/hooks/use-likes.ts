"use client";

import { useState, useEffect, useCallback } from "react";
import { incrementLike, decrementLike, getLikeCounts } from "@/db/actions/like-actions";
import { RECIPES } from "@/features/app/data/recipes";

const STORAGE_KEY = "recipebook_likes";

function getLikedIds(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? new Set(JSON.parse(raw) as string[]) : new Set();
  } catch {
    return new Set();
  }
}

function saveLikedIds(ids: Set<string>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...ids]));
  } catch {
    // storage full or unavailable
  }
}

export function useLikes() {
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  // Global like counts from the DB
  const [globalCounts, setGlobalCounts] = useState<Record<string, number>>({});

  // Load local likes + global counts on mount
  useEffect(() => {
    const local = getLikedIds();
    setLikedIds(local);

    const allIds = RECIPES.map((r) => r.id);
    getLikeCounts(allIds).then((counts) => {
      setGlobalCounts(counts);
    }).catch(() => {
      // Non-critical — counts just won't show
    });
  }, []);

  const toggleLike = useCallback(async (recipeId: string) => {
    let wasLiked = false;
    setLikedIds((prev) => {
      wasLiked = prev.has(recipeId);
      const next = new Set(prev);
      if (wasLiked) {
        next.delete(recipeId);
      } else {
        next.add(recipeId);
      }
      saveLikedIds(next);
      return next;
    });

    // Update global count in DB
    try {
      const newCount = wasLiked
        ? await decrementLike(recipeId)
        : await incrementLike(recipeId);
      setGlobalCounts((prev) => ({ ...prev, [recipeId]: newCount }));
    } catch {
      // Optimistic update: just adjust locally
      setGlobalCounts((prev) => ({
        ...prev,
        [recipeId]: Math.max(0, (prev[recipeId] ?? 0) + (wasLiked ? -1 : 1)),
      }));
    }
  }, []);

  const isLiked = useCallback(
    (recipeId: string) => likedIds.has(recipeId),
    [likedIds]
  );

  const getGlobalCount = useCallback(
    (recipeId: string) => globalCounts[recipeId] ?? 0,
    [globalCounts]
  );

  return { isLiked, toggleLike, likedCount: likedIds.size, getGlobalCount };
}
