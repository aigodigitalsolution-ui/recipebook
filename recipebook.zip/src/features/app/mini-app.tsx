"use client";

import { useState, useMemo, useEffect } from "react";
import { RecipeCard } from "@/features/app/components/recipe-card";
import { RecipeDetail } from "@/features/app/components/recipe-detail";
import { FilterBar } from "@/features/app/components/filter-bar";
import { RECIPES } from "@/features/app/data/recipes";
import { useLikes } from "@/features/app/hooks/use-likes";
import type { Recipe, RecipeCategory, Cuisine, DietaryTag } from "@/features/app/types";
import { ShareButton } from "@/neynar-farcaster-sdk/mini";
import { cn } from "@neynar/ui";

type Tab = "browse" | "new" | "saved";

const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;

export function MiniApp() {
  const [activeTab, setActiveTab] = useState<Tab>("browse");
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [activeCategory, setActiveCategory] = useState<RecipeCategory | "all">("all");
  const [activeCuisine, setActiveCuisine] = useState<Cuisine | "all">("all");
  const [activeSpice, setActiveSpice] = useState<"all" | "mild" | "spicy">("all");
  const [activeDietary, setActiveDietary] = useState<DietaryTag | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [filtersVisible, setFiltersVisible] = useState(true);
  const { isLiked, toggleLike, likedCount, getGlobalCount } = useLikes();

  // Browse: filtered + sorted by global likes descending
  const filteredRecipes = useMemo(() => {
    const filtered = RECIPES.filter((recipe) => {
      const matchesCategory = activeCategory === "all" || recipe.category === activeCategory;
      const matchesCuisine = activeCuisine === "all" || recipe.cuisine === activeCuisine;
      const matchesSpice =
        activeSpice === "all" ||
        (activeSpice === "spicy" && recipe.spicy) ||
        (activeSpice === "mild" && !recipe.spicy);
      const matchesDietary =
        activeDietary === "all" || recipe.dietary.includes(activeDietary);
      const matchesSearch =
        searchQuery === "" ||
        recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesCuisine && matchesSpice && matchesDietary && matchesSearch;
    });
    // Sort by most loved
    return [...filtered].sort((a, b) => getGlobalCount(b.id) - getGlobalCount(a.id));
  }, [activeCategory, activeCuisine, activeSpice, activeDietary, searchQuery, getGlobalCount]);

  // New tab: defer to client only to avoid SSR/hydration mismatch with Date.now()
  const [newRecipes, setNewRecipes] = useState<Recipe[]>([]);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
    const now = Date.now();
    const recent = RECIPES.filter((r) => {
      const added = new Date(r.addedAt).getTime();
      return now - added <= ONE_WEEK_MS;
    }).sort((a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime());
    setNewRecipes(recent);
  }, []);

  const savedRecipes = useMemo(
    () => RECIPES.filter((r) => isLiked(r.id)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [likedCount, isLiked]
  );

  const activeFilterCount = [
    activeCategory !== "all",
    activeCuisine !== "all",
    activeSpice !== "all",
    activeDietary !== "all",
  ].filter(Boolean).length;

  const headerSubtitle = useMemo(() => {
    if (!mounted) return `${RECIPES.length} recipes`;
    if (activeTab === "browse") {
      return (
        <>
          {filteredRecipes.length} of {RECIPES.length} recipes · sorted by popular
          {activeFilterCount > 0 && (
            <span className="ml-1.5 text-[#d4a017]">
              · {activeFilterCount} filter{activeFilterCount > 1 ? "s" : ""}
            </span>
          )}
        </>
      );
    }
    if (activeTab === "new") {
      return newRecipes.length > 0
        ? `${newRecipes.length} new this week`
        : "No new recipes this week";
    }
    return likedCount > 0
      ? `${likedCount} saved recipe${likedCount > 1 ? "s" : ""}`
      : "No saved recipes yet";
  }, [mounted, activeTab, filteredRecipes.length, newRecipes.length, likedCount, activeFilterCount]);

  // Recipe detail view
  if (selectedRecipe) {
    return (
      <div className="h-dvh flex flex-col overflow-hidden bg-[#0f0e0d]">
        <RecipeDetail
          recipe={selectedRecipe}
          liked={isLiked(selectedRecipe.id)}
          onLike={toggleLike}
          onBack={() => setSelectedRecipe(null)}
          globalLikeCount={getGlobalCount(selectedRecipe.id)}
          shareIconButton={
            <ShareButton
              text={`Just found this amazing recipe on Recipebook! \uD83C\uDF7D\uFE0F`}
              queryParams={{
                recipeTitle: selectedRecipe.title,
                recipeEmoji: selectedRecipe.emoji,
              }}
              className="w-10 h-10 !rounded-full !p-0 flex items-center justify-center"
            >
              <span className="text-lg">↗</span>
            </ShareButton>
          }
        />
      </div>
    );
  }

  return (
    <div className="h-dvh flex flex-col overflow-hidden bg-[#0f0e0d]">
      {/* Header */}
      <header className="shrink-0 px-4 pt-5 pb-4 border-b border-[#2e2820]">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-[#f5f0e8] tracking-tight">Recipebook</h1>
            <p className="text-sm text-[#8a7a62] mt-0.5">{headerSubtitle}</p>
          </div>
          <div className="flex items-center gap-2">
            {activeTab === "browse" && activeFilterCount > 0 && (
              <button
                onClick={() => {
                  setActiveCategory("all");
                  setActiveCuisine("all");
                  setActiveSpice("all");
                  setActiveDietary("all");
                }}
                className="text-xs text-[#d4a017] border border-[#d4a017]/30 rounded-full px-2.5 py-1 hover:bg-[#d4a017]/10 transition-colors"
              >
                Clear
              </button>
            )}
            <div className="w-10 h-10 rounded-xl bg-[#d4a017]/10 border border-[#d4a017]/20 flex items-center justify-center text-xl">
              📖
            </div>
          </div>
        </div>

        {/* Search + filter toggle — only on browse tab */}
        {activeTab === "browse" && (
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8a7a62]">🔍</span>
              <input
                type="text"
                placeholder="Search recipes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-11 pl-9 pr-4 rounded-xl bg-[#1a1814] border border-[#2e2820] text-[#f5f0e8] placeholder:text-[#8a7a62] text-sm focus:outline-none focus:border-[#d4a017]/50 transition-colors"
              />
            </div>
            <button
              onClick={() => setFiltersVisible((v) => !v)}
              className={cn(
                "relative h-11 w-11 shrink-0 rounded-xl border flex items-center justify-center text-lg transition-all duration-200",
                filtersVisible || activeFilterCount > 0
                  ? "bg-[#d4a017]/15 border-[#d4a017]/40 text-[#d4a017]"
                  : "bg-[#1a1814] border-[#2e2820] text-[#8a7a62] hover:border-[#d4a017]/30 hover:text-[#d4a017]"
              )}
              aria-label={filtersVisible ? "Hide filters" : "Show filters"}
            >
              {filtersVisible ? "▲" : "▼"}
              {activeFilterCount > 0 && !filtersVisible && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#d4a017] text-[#0f0e0d] text-[10px] font-bold rounded-full flex items-center justify-center">
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>
        )}
      </header>

      {/* Filters — collapsible, only on browse tab */}
      {activeTab === "browse" && filtersVisible && (
        <div className="shrink-0 border-b border-[#2e2820]">
          <FilterBar
            activeCategory={activeCategory}
            activeCuisine={activeCuisine}
            activeSpice={activeSpice}
            activeDietary={activeDietary}
            onCategoryChange={setActiveCategory}
            onCuisineChange={setActiveCuisine}
            onSpiceChange={setActiveSpice}
            onDietaryChange={setActiveDietary}
          />
        </div>
      )}

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-4">
        {/* Skeleton shown during SSR / before hydration — prevents mismatch */}
        {!mounted && (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-24 rounded-xl bg-[#1a1814] border border-[#2e2820] animate-pulse" />
            ))}
          </div>
        )}

        {mounted && activeTab === "browse" && (
          filteredRecipes.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="text-4xl mb-3">🍽️</div>
              <p className="font-semibold text-[#f5f0e8] text-base">No recipes found</p>
              <p className="text-sm text-[#8a7a62] mt-1">Try a different search or filter</p>
              {activeFilterCount > 0 && (
                <button
                  onClick={() => { setActiveCategory("all"); setActiveCuisine("all"); setActiveSpice("all"); setActiveDietary("all"); }}
                  className="mt-4 text-sm text-[#d4a017] border border-[#d4a017]/30 rounded-full px-4 py-2 hover:bg-[#d4a017]/10 transition-colors"
                >
                  Clear all filters
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredRecipes.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  liked={isLiked(recipe.id)}
                  onLike={toggleLike}
                  onClick={setSelectedRecipe}
                  globalLikeCount={getGlobalCount(recipe.id)}
                />
              ))}
            </div>
          )
        )}

        {mounted && activeTab === "new" && (
          newRecipes.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="text-5xl mb-4">✨</div>
              <p className="font-semibold text-[#f5f0e8] text-base">Nothing new this week</p>
              <p className="text-sm text-[#8a7a62] mt-2 max-w-[220px] leading-relaxed">
                Check back soon — new recipes are added regularly.
              </p>
              <button
                onClick={() => setActiveTab("browse")}
                className="mt-5 text-sm text-[#d4a017] border border-[#d4a017]/30 rounded-full px-5 py-2 hover:bg-[#d4a017]/10 transition-colors"
              >
                Browse all recipes
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-semibold uppercase tracking-widest text-[#d4a017]">
                  Added this week
                </span>
                <div className="flex-1 h-px bg-[#2e2820]" />
              </div>
              {newRecipes.map((recipe) => (
                <div key={recipe.id} className="relative">
                  <RecipeCard
                    recipe={recipe}
                    liked={isLiked(recipe.id)}
                    onLike={toggleLike}
                    onClick={setSelectedRecipe}
                    globalLikeCount={getGlobalCount(recipe.id)}
                    showDate
                  />
                  <span className="absolute top-2 left-2 bg-[#d4a017] text-[#0f0e0d] text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-full pointer-events-none">
                    New
                  </span>
                </div>
              ))}
            </div>
          )
        )}

        {mounted && activeTab === "saved" && (
          savedRecipes.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="text-5xl mb-4">🤍</div>
              <p className="font-semibold text-[#f5f0e8] text-base">No saved recipes yet</p>
              <p className="text-sm text-[#8a7a62] mt-2 max-w-[220px] leading-relaxed">
                Tap the heart on any recipe to save it here for easy access.
              </p>
              <button
                onClick={() => setActiveTab("browse")}
                className="mt-5 text-sm text-[#d4a017] border border-[#d4a017]/30 rounded-full px-5 py-2 hover:bg-[#d4a017]/10 transition-colors"
              >
                Browse recipes
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {savedRecipes.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  liked={true}
                  onLike={toggleLike}
                  onClick={setSelectedRecipe}
                  globalLikeCount={getGlobalCount(recipe.id)}
                />
              ))}
            </div>
          )
        )}
      </main>

      {/* Bottom tab bar */}
      <nav className="shrink-0 flex border-t border-[#2e2820] bg-[#0f0e0d]">
        <button
          onClick={() => setActiveTab("browse")}
          className={cn(
            "flex-1 flex flex-col items-center justify-center gap-1 py-3 transition-colors",
            activeTab === "browse" ? "text-[#d4a017]" : "text-[#8a7a62] hover:text-[#c4b99a]"
          )}
        >
          <span className="text-xl">🍽️</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider">Browse</span>
        </button>
        <button
          onClick={() => setActiveTab("new")}
          className={cn(
            "flex-1 flex flex-col items-center justify-center gap-1 py-3 transition-colors relative",
            activeTab === "new" ? "text-[#d4a017]" : "text-[#8a7a62] hover:text-[#c4b99a]"
          )}
        >
          <span className="text-xl relative" suppressHydrationWarning>
            ✨
            {mounted && newRecipes.length > 0 && (
              <span className="absolute -top-1 -right-2 min-w-[16px] h-4 bg-[#d4a017] text-[#0f0e0d] text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {newRecipes.length}
              </span>
            )}
          </span>
          <span className="text-[10px] font-semibold uppercase tracking-wider">New</span>
        </button>
        <button
          onClick={() => setActiveTab("saved")}
          className={cn(
            "flex-1 flex flex-col items-center justify-center gap-1 py-3 transition-colors relative",
            activeTab === "saved" ? "text-rose-400" : "text-[#8a7a62] hover:text-[#c4b99a]"
          )}
        >
          <span className="text-xl relative">
            ❤️
            {likedCount > 0 && (
              <span className="absolute -top-1 -right-2 min-w-[16px] h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {likedCount}
              </span>
            )}
          </span>
          <span className="text-[10px] font-semibold uppercase tracking-wider">Saved</span>
        </button>
      </nav>
    </div>
  );
}
