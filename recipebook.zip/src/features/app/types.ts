export type RecipeCategory =
  | "breakfast"
  | "lunch"
  | "dinner"
  | "dessert"
  | "snack"
  | "drink";

export type DifficultyLevel = "easy" | "medium" | "hard";

export type SpiceLevel = "mild" | "medium" | "hot";

export type DietaryTag = "vegan" | "vegetarian" | "gluten-free" | "dairy-free" | "high-protein";

export type Cuisine =
  | "italian"
  | "japanese"
  | "thai"
  | "mexican"
  | "indonesian"
  | "indian"
  | "middle-eastern"
  | "spanish"
  | "american"
  | "french"
  | "malaysian"
  | "singaporean"
  | "international";

export interface Ingredient {
  amount: string;
  unit: string;
  name: string;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  category: RecipeCategory;
  difficulty: DifficultyLevel;
  prepTime: number; // minutes
  cookTime: number; // minutes
  servings: number;
  emoji: string;
  imageUrl: string;
  ingredients: Ingredient[];
  steps: string[];
  tags: string[];
  cuisine: Cuisine;
  spicy: boolean;
  spiceLevel?: SpiceLevel;
  addedAt: string; // ISO date string
  calories: number; // per serving (estimated)
  dietary: DietaryTag[]; // dietary categories
}
